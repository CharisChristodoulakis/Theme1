using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float movespeed;

    //public Rigidbody theRB;
    public float jumpForce;
    public CharacterController Controller;

    private Vector3 moveDirection;
    public float gravityScale;

    void Start()
    {
        //theRB = GetComponent<Rigidbody>();
        Controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {

        //theRB.velocity = new Vector3(Input.GetAxis("Horizontal") * movespeed, theRB.velocity.y, Input.GetAxis("Vertical") * movespeed);

        /*  if (Input.GetButton("Jump"))
          {
              theRB.velocity = new Vector3(theRB.velocity.x, jumpforce, theRB.velocity.z);
          } */

        //moveDirection = new Vector3(Input.GetAxis("Horizontal") * movespeed, moveDirection.y, Input.GetAxis("Vertical") * movespeed);
        float yStore = moveDirection.y;
        moveDirection = (transform.forward * Input.GetAxis("Vertical")) + (transform.right * Input.GetAxis("Horizontal"));
        moveDirection = moveDirection.normalized * movespeed;
        moveDirection.y = yStore;

        if (Controller.isGrounded) //Camera Controller 
        {

            moveDirection.y = 0f;
            if (Input.GetButtonDown("Jump"))  //Jump Button
            {
                moveDirection.y = jumpForce;
            }
        }

        moveDirection.y = moveDirection.y + (Physics.gravity.y * gravityScale * Time.deltaTime);
        Controller.Move(moveDirection * Time.deltaTime);
    }
}


    


    